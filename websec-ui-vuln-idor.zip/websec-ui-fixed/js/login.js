if (getToken()) {
    window.location.href = "app.html";
}

let requestInFlight = false;  // samo blokira dupli klik na ISTI request

async function login() {
    if (requestInFlight) return;  // ceka da se trenutni HTTP request zavrsi

    const btn = document.getElementById("loginBtn");
    const errorEl = document.getElementById("error");

    requestInFlight = true;
    btn.disabled = true;

    let response;
    try {
        response = await fetch(`${API_URL}/auth/login`, {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                email: email.value,
                password: password.value
            })
        });
    } catch (networkErr) {
        errorEl.innerText = "Mrežna greška. Pokušajte ponovo.";
        requestInFlight = false;
        btn.disabled = false;
        return;
    }

    if (response.status === 429) {
        const data = await response.json().catch(() => ({}));
        const retryAfter = parseInt(
            response.headers.get("Retry-After") || data.retryAfterSeconds || "5"
        );
        startCountdown(retryAfter, btn, errorEl);
        requestInFlight = false;
        // btn ostaje disabled tokom countdowna
        return;
    }

    // Odmah re-enable posle 401 — svaki klik MORA da stigne do servera
    // jer server broji pokusaje i vraca 429 tek kad dodje do praga
    requestInFlight = false;
    btn.disabled = false;

    if (!response.ok) {
        errorEl.innerText = "Pogrešan e-mail ili lozinka.";
        return;
    }

    const data = await response.json();
    setToken(data.accessToken);
    window.location.href = "app.html";
}

function startCountdown(seconds, btn, errorEl) {
    let remaining = seconds;
    btn.disabled = true;
    errorEl.innerText = `Previše pokušaja! Sačekajte ${remaining}s.`;

    const interval = setInterval(() => {
        remaining--;
        if (remaining <= 0) {
            clearInterval(interval);
            errorEl.innerText = "";
            btn.disabled = false;
        } else {
            errorEl.innerText = `Previše pokušaja! Sačekajte ${remaining}s.`;
        }
    }, 1000);
}
