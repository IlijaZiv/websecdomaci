if (getToken()) {
    window.location.href = "app.html";
}

async function login() {
    const btn = document.getElementById("loginBtn");
    const errorEl = document.getElementById("error");

    errorEl.innerText = "";
    btn.disabled = true;

    const response = await fetch(`${API_URL}/auth/login`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            email: email.value,
            password: password.value
        })
    });

    if (response.status === 429) {
        const data = await response.json();
        const seconds = parseInt(data.retryAfterSeconds) || 5;
        startCountdown(seconds, errorEl, btn);
        return;
    }

    btn.disabled = false;

    if (!response.ok) {
        errorEl.innerText = "Invalid email or password";
        return;
    }

    const data = await response.json();
    setToken(data.accessToken);
    window.location.href = "app.html";
}

function startCountdown(seconds, errorEl, btn) {
    let remaining = seconds;
    errorEl.innerText = `Too many failed attempts. Try again in ${remaining}s`;

    const interval = setInterval(() => {
        remaining--;
        if (remaining <= 0) {
            clearInterval(interval);
            errorEl.innerText = "You can try again now.";
            btn.disabled = false;
        } else {
            errorEl.innerText = `Too many failed attempts. Try again in ${remaining}s`;
        }
    }, 1000);
}
